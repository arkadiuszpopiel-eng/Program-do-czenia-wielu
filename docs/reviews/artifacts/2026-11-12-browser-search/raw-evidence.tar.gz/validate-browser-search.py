import subprocess,json,sys,pathlib,tomllib
cmds=[['cargo','+1.94.1','fmt','--all','--','--check'],['cargo','+1.94.1','metadata','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--locked','--offline','--format-version','1'],['bash','scripts/check-deps.sh'],['node','scripts/gen-ipc-types.mjs','--check'],['node','scripts/docs-html.mjs','--verify'],['pnpm','exec','prettier','--check','crates/tools-browser-contract/README.md','crates/tools-browser-impl/README.md','docs/vendor/form-urlencoded.md'],['pnpm','lint']]
results=[]
for cmd in cmds:
 print(json.dumps({'command':cmd}),flush=True);p=subprocess.run(cmd);results.append({'command':cmd,'exit':p.returncode});print(json.dumps(results[-1]),flush=True)
 if p.returncode:break
pathlib.Path('/workspace/scratch/repair-20261111/browser-search-validation-commands.json').write_text(json.dumps(results,indent=2)+'\n');sys.exit(results[-1]['exit'])
