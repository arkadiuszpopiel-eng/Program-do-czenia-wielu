import subprocess,json,sys,pathlib
cmds=[['cargo','+1.94.1','fmt','--all','--','--check'],['bash','scripts/check-deps.sh'],['node','scripts/gen-ipc-types.mjs','--check'],['node','scripts/docs-html.mjs','--verify'],['pnpm','exec','prettier','--check','scripts/gen-ipc-types.mjs','crates/lib-client-wire/README.md','apps/desktop/ui/src/lib/api/generated/ipc.ts'],['pnpm','lint'],['pnpm','check']]
results=[]
for cmd in cmds:
 print(json.dumps({'command':cmd}),flush=True);p=subprocess.run(cmd);results.append({'command':cmd,'exit':p.returncode});print(json.dumps(results[-1]),flush=True)
 if p.returncode:break
pathlib.Path('/workspace/scratch/repair-20261111/wire-validation-commands.json').write_text(json.dumps(results,indent=2)+'\n');sys.exit(results[-1]['exit'])
