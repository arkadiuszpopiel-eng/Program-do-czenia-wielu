import pathlib,json,time,subprocess
r=pathlib.Path(__file__).parent;wt='/workspace/wt-router-expert-roles';f=r/'expert-roles-clippy.json'
while json.loads(f.read_text())['state']!='completed':time.sleep(2)
assert json.loads(f.read_text())['exit']==0
for key,cmd in [
 ('expert-roles-app-modules',['cargo','+1.94.1','test','--locked','-p','app-modules','--lib','-j2']),
 ('expert-roles-app-core',['cargo','+1.94.1','test','--locked','-p','app-core','--test','routing','--test','model_routing','--test','pipeline_routing','-j2']),
 ('expert-roles-fmt-check',['cargo','+1.94.1','fmt','--all','--','--check'])]:
 subprocess.run(['python3',str(r/'run_logged.py'),key,wt,*cmd],check=True)
 d=json.loads((r/(key+'.json')).read_text());print(json.dumps({'stage':key,'exit':d['exit']}),flush=True)
 if d['exit']!=0:break
