import hashlib, json, pathlib, sys, tarfile

root = pathlib.Path(__file__).parent
config = json.loads(pathlib.Path(sys.argv[1]).read_text())
wt = pathlib.Path(config['worktree'])
out = wt / config['destination']
out.mkdir(parents=True, exist_ok=True)
files = []
for pattern in config['patterns']:
    found = sorted(root.glob(pattern))
    assert found, pattern
    files.extend(p for p in found if p.is_file())
files = sorted(set(files))
manifest = {'base': config['base'], 'scope': config['scope'], 'files': [], 'sources': []}
archive = out / 'raw-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for p in files:
        name = str(p.relative_to(root))
        manifest['files'].append({'path': name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
        tf.add(p, arcname=name, recursive=False)
for name in config.get('sources', []):
    p = wt / name
    manifest['sources'].append({'path': name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
manifest['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'files': len(files), 'bytes': archive.stat().st_size, 'sha256': manifest['archive_sha256']}))
