import subprocess,pathlib,datetime,json,hashlib,os,sys
root=pathlib.Path(__file__).parent
key,cwd,*cmd=sys.argv[1:];base=root/key;env=os.environ.copy()
env.update(PATH='/workspace/tools/cargo/bin:/workspace/tools/cmake/cmake/data/bin:/workspace/tools/pnpm/node_modules/.bin:'+env['PATH'],RUSTUP_HOME='/workspace/tools/rustup',CARGO_HOME='/workspace/tools/cargo',RUSTUP_TOOLCHAIN='1.94.1',CARGO_TARGET_DIR='/workspace/target-repair',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
def git(*args):return subprocess.check_output(['git',*args],cwd=cwd).decode().strip()
s={'command':cmd,'cwd':cwd,'source_head':git('rev-parse','HEAD'),'source_status':git('status','--short'),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'running'}
with base.with_suffix('.log').open('wb') as f:
 p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);s.update(pid=p.pid,group=p.pid,birth=pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21]);base.with_suffix('.json').write_text(json.dumps(s,indent=2));code=p.wait()
s.update(state='completed',exit=code,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256(base.with_suffix('.log').read_bytes()).hexdigest());base.with_suffix('.json').write_text(json.dumps(s,indent=2));print(json.dumps({k:s[k] for k in ['command','cwd','source_head','state','exit','end','log_sha256']}))
