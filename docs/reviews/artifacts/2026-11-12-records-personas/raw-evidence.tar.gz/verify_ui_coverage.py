"""Audit distinct frozen-source tests; never conceal the earlier failed attempt."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
state_path = root / "ui-shards-resume.json"
state = json.loads(state_path.read_text())
if state["state"] != "completed":
    raise SystemExit("UI controller has not completed")
parts = state["preserved_shards"] + state["results"]
assert sorted(p["shard"] for p in parts) == [1, 2, 3, 4]


def walk(suite):
    for spec in suite.get("specs", []):
        yield spec
    for child in suite.get("suites", []):
        yield from walk(child)


expected, actual, inventory = set(), set(), []
for part in sorted(parts, key=lambda p: p["shard"]):
    shard = part["shard"]
    stem = "ui-shard-1" if shard == 1 else f"ui-resume-shard-{shard}"
    listed = json.loads((root / f"{stem}-list.json").read_text())
    ids = {spec["id"] for suite in listed["suites"] for spec in walk(suite)}
    assert not expected.intersection(ids), ("overlapping inventory", shard)
    assert len(ids) == part["expected_tests"]
    expected.update(ids)
    seen = set()
    assert part["exit"] == 0 and not part["errors"]
    for spec in part["results"]:
        assert spec["id"] not in seen and spec["id"] not in actual
        seen.add(spec["id"])
        for test in spec["tests"]:
            assert test["status"] == "expected", test
            assert test["expectedStatus"] == "passed", test
            assert len(test["attempts"]) == 1, test
            assert test["attempts"][0]["status"] == "passed", test
            assert test["attempts"][0]["retry"] == 0, test
    assert seen == ids
    actual.update(seen)
    for suffix, key in [(".log", "log_sha256"), ("-report.json", "report_sha256"),
                        ("-results.tar.gz", "results_archive_sha256")]:
        assert hashlib.sha256((root / (stem + suffix)).read_bytes()).hexdigest() == part[key]
    inventory.append({"shard": shard, "tests": len(seen), "start": part["start"],
                      "end": part["end"], "stats": part["stats"], "evidence_prefix": stem})
assert expected == actual and len(actual) == 961
result = {"source": state["source"], "unique_expected": len(expected),
          "unique_passed": len(actual), "failed_in_final_coverage": 0,
          "skipped": 0, "flaky": 0, "internal_retries": 0, "parts": inventory,
          "original_failure_unresolved": state["original_failure_unresolved"],
          "original_attempt": "ui-shards.json:345passed/1failed/615notrun",
          "resume": "whole shard2 repeated once, then previously unrun3/4; same source and budgets",
          "not_a_clean_first_pass": True,
          "state_sha256": hashlib.sha256(state_path.read_bytes()).hexdigest()}
(root / "ui-coverage-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "parts"}, ensure_ascii=False))
