"""Pilot rzeczywistego modelu: dane z Core i jawna ablacja; bez działań komputera."""
import datetime
import hashlib
import http.client
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import threading
import time

ROOT = Path('/workspace/scratch/repair-20261111')
REPO = Path('/workspace/wt-nightly')
SERVER = Path('/workspace/tools/llama/llama-b11559/llama-server')
ENTRY = json.loads((ROOT/'main-model-entry.json').read_text())
FIXTURE = ROOT/'core-captured-records'
VARIANT = sys.argv[1]
assert VARIANT in ('records_user_data', 'records_ablation')
assert json.loads((ROOT/'main-model-download.json').read_text()).get('verification') == 'MATCH'
assert hashlib.sha256(SERVER.read_bytes()).hexdigest() == '16c4e5fc3e0a74400033d958722e487a797dbb51c676f5ce1ec9066f1673efd5'
assert json.loads((ROOT/'rust-batches.json').read_text())['state'] == 'completed', 'No model alongside Rust suite'
OUT = ROOT/('pilot-'+VARIANT)
OUT.mkdir(exist_ok=False)

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def request_body(case):
    req = case['provider_request']
    messages = [{'role':'system', 'content':req['system']}]
    seen = 0
    for m in req['messages']:
        assert m['role'] in ('user', 'assistant')
        assert all(b['type'] == 'text' for b in m['content'])
        text = ''.join(b['text'] for b in m['content'])
        if text.startswith('[Zapis czynności aplikacji]'):
            seen += 1
            if VARIANT == 'records_ablation':
                continue
        messages.append({'role':m['role'], 'content':text})
    assert seen == 1
    assert messages[-1]['role'] == 'user'
    return {'model':ENTRY['id'], 'messages':messages, 'max_tokens':96,
            'temperature':0, 'stream':True, 'stream_options':{'include_usage':True}}

with socket.socket() as sock:
    sock.bind(('127.0.0.1',0))
    port = sock.getsockname()[1]
auth = secrets.token_urlsafe(32)  # Nowy klucz tego serwera, bez odczytu kont/CLI.
args = [str(SERVER), '--host','127.0.0.1', '--port',str(port), '-m',
        str(Path('/workspace/models')/ENTRY['file']), '-c','8192', '-ngl','0',
        '--threads','4', '-np','1', '--jinja', '--alias',ENTRY['id'],
        '--chat-template-kwargs','{"enable_thinking":false}', '--api-key',auth]
status = {'variant':VARIANT, 'state':'starting', 'start':stamp(), 'model':ENTRY,
          'scope':'rawHTTP outsideCore; exact Core captured request from c502; synthetic prior records; no businessaction executed',
          'hypothesis':'compare exact records user-data input against explicit context ablation; no synthetic tool call/result or answer correction',
          'fixture_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in FIXTURE.glob('*.json')},
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'startup_s':60, 'first_generation_s':60, 'idle_generation_s':30,
          'turn_s':120, 'max_tokens':96, 'temperature':0, 'threads':4,
          'ping_setting':'unchanged server default',
          'server_args':[x if x != auth else '<ephemeral-test-auth-redacted>' for x in args],
          'results':[]}

def save():
    p = OUT/'status.tmp'
    p.write_text(json.dumps(status, ensure_ascii=False, indent=2)+'\n')
    p.replace(OUT/'status.json')

def server_log(stream):
    with (OUT/'server.log').open('w') as log:
        for line in iter(stream.readline, b''):
            log.write(line.decode('utf-8',errors='replace').replace(auth,'<ephemeral-test-auth-redacted>'))
            log.flush()

process = None
boot = time.monotonic()
save()
try:
    process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
    status.update(pid=process.pid, group=process.pid,
                  birth=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19])
    threading.Thread(target=server_log, args=(process.stdout,), daemon=True).start()
    save()
    while True:
        if process.poll() is not None:
            raise RuntimeError('own server exited before ready')
        try:
            c = http.client.HTTPConnection('127.0.0.1',port,timeout=2)
            c.request('GET','/health',headers={'Authorization':'Bearer '+auth})
            response = c.getresponse(); response.read(); ready = response.status == 200; c.close()
            if ready:
                break
        except OSError:
            pass
        if time.monotonic()-boot >= 60:
            raise TimeoutError('startup60s')
        time.sleep(.25)
    status.update(state='running', load_ms=round((time.monotonic()-boot)*1000)); save()
    cases = [{'scenario':n,'provider_request':json.loads((FIXTURE/(n+'.json')).read_text())} for n in ['empty_record','recorded_done','needs_confirmation']]
    for case in cases:
        body = request_body(case)
        (OUT/(case['scenario']+'-request.json')).write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n')
        result = {'scenario':case['scenario'], 'text':'', 'reasoning_chars':0, 'error':None,
                  'first_text_http_ms':None, 'first_generation_http_ms':None,
                  'finish_reasons':[], 'usage':None, 'events':[]}
        start = time.monotonic(); last_progress = None; buffer = b''; done = False
        c = http.client.HTTPConnection('127.0.0.1',port,timeout=2)
        try:
            c.connect(); c.sock.settimeout(60)
            c.request('POST','/v1/chat/completions',json.dumps(body).encode(),
                      headers={'Content-Type':'application/json','Authorization':'Bearer '+auth})
            response = c.getresponse(); result['http_status'] = response.status
            if response.status != 200:
                result['error_body'] = response.read(8192).decode('utf-8',errors='replace').replace(auth,'<ephemeral-test-auth-redacted>')
                raise RuntimeError('HTTP'+str(response.status))
            while not done:
                deadline = min(start+120, start+60 if last_progress is None else last_progress+30)
                now = time.monotonic()
                if now >= deadline:
                    raise TimeoutError('generation deadline; no retry')
                c.sock.settimeout(deadline-now)
                chunk = response.read1(65536)
                if not chunk:
                    break
                buffer += chunk
                while b'\n' in buffer:
                    line, buffer = buffer.split(b'\n',1)
                    if not line.startswith(b'data:'):
                        continue
                    payload = line[5:].strip()
                    if payload == b'[DONE]':
                        done = True; break
                    data = json.loads(payload); now = time.monotonic(); event = {'ms':round((now-start)*1000)}
                    if data.get('usage') is not None:
                        result['usage'] = data['usage']
                    for choice in data.get('choices',[]):
                        delta = choice.get('delta',{}); text = delta.get('content') or ''
                        reasoning = delta.get('reasoning_content') or delta.get('reasoning') or ''
                        tool = delta.get('tool_calls') or []
                        progress = bool(text or reasoning or delta.get('refusal') or any(t.get('function',{}).get('name') or t.get('function',{}).get('arguments') for t in tool))
                        if progress:
                            last_progress = now
                            if result['first_generation_http_ms'] is None:
                                result['first_generation_http_ms'] = event['ms']
                        if text:
                            result['text'] += text
                            if result['first_text_http_ms'] is None:
                                result['first_text_http_ms'] = event['ms']
                        result['reasoning_chars'] += len(reasoning)
                        event.update(text_chars=len(text), reasoning_chars=len(reasoning), tool_calls=tool)
                        if choice.get('finish_reason') is not None:
                            result['finish_reasons'].append(choice['finish_reason'])
                    result['events'].append(event)
        except (OSError,ValueError,RuntimeError) as error:
            result['error'] = type(error).__name__+': '+str(error)
        finally:
            c.close()
        result.update(elapsed_ms=round((time.monotonic()-start)*1000),
                      first_text_within_http60=result['first_text_http_ms'] is not None and result['first_text_http_ms']<=60000)
        status['results'].append(result); save()
        print(json.dumps({k:v for k,v in result.items() if k != 'events'},ensure_ascii=False),flush=True)
        if result['error']:
            break
except (OSError,RuntimeError) as error:
    status['error'] = type(error).__name__+': '+str(error)
finally:
    if process and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill(); process.wait(); status['cleanup']='own server SIGTERM then SIGKILL'
    if process:
        status['server_exit']=process.returncode
    status.update(state='completed',end=stamp(),not_run=[n for n in ['empty_record','recorded_done','needs_confirmation'] if n not in {r['scenario'] for r in status['results']}]); save()
