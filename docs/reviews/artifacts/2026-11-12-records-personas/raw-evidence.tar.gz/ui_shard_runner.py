"""Cztery kolejne lokalne shardy; nie zmienia CI/progów, zachowuje wszystkie wyniki."""
import datetime, hashlib, json, os, pathlib, subprocess, tarfile
ROOT=pathlib.Path('/workspace/scratch/repair-20261111'); REPO=pathlib.Path('/workspace/wt-jarvis'); UI=REPO/'apps/desktop/ui'; STATE=ROOT/'ui-shards.json'
env=os.environ.copy();env.update(PATH='/workspace/tools/pnpm/node_modules/.bin:'+env['PATH'],PW_WORKERS='1',CI='1')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO,text=True).strip()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def specs(suites):
 for s in suites:
  yield from s.get('specs',[])
  yield from specs(s.get('suites',[]))
assert not STATE.exists(),'Do not start duplicate run'
assert json.loads((ROOT/'rust-batches.json').read_text())['state']=='completed'
assert not git('status','--porcelain'), 'Freeze source before full UI'
state={'source':git('rev-parse','HEAD'),'start':now(),'scope':'headless Linux/Chromium/fakeIPC; no hardware acceptance','controller':{'pid':os.getpid(),'group':os.getpgid(os.getpid()),'birth':pathlib.Path(f'/proc/{os.getpid()}/stat').read_text().split()[21]},'results':[],'state':'listing'}
def save():
 p=STATE.with_suffix('.tmp');p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');p.replace(STATE)
save();sets=[]
for n in range(1,5):
 p=ROOT/f'ui-shard-{n}-list.json';r=subprocess.run(['pnpm','exec','playwright','test','--list',f'--shard={n}/4','--reporter=json'],cwd=UI,env=env,capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 p.write_text(r.stdout); report=json.loads(r.stdout);ids={s['id'] for s in specs(report['suites'])};assert ids;sets.append(ids)
all_ids=set().union(*sets);assert sum(map(len,sets))==len(all_ids),'shards overlap'
state['unique_tests']=len(all_ids);state['counts']=[len(s) for s in sets];save()
for n,expected in enumerate(sets,1):
 assert git('rev-parse','HEAD')==state['source'] and not git('status','--porcelain')
 if (ROOT/'ui-shards.stop').exists():state['state']='stopped';save();break
 reportpath=ROOT/f'ui-shard-{n}-report.json';env['PLAYWRIGHT_JSON_OUTPUT_FILE']=str(reportpath)
 cmd=['pnpm','exec','playwright','test',f'--shard={n}/4','--workers=1','--max-failures=1','--reporter=line,json'];log=ROOT/f'ui-shard-{n}.log';r={'shard':n,'command':cmd,'expected_tests':len(expected),'start':now()};state.update(state='running',active=r)
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=UI,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);r.update(pid=p.pid,group=p.pid,birth=pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21]);save()
  while True:
   try:code=p.wait(timeout=30);break
   except subprocess.TimeoutExpired:state['heartbeat_at']=now();save()
 r.update(exit=code,end=now(),log_sha256=sha(log))
 if reportpath.exists():
  report=json.loads(reportpath.read_text());r['stats']=report['stats'];r['errors']=report.get('errors',[]);r['report_sha256']=sha(reportpath)
  seen={s['id'] for s in specs(report['suites'])};assert seen==expected, 'report targets changed'
  r['results']=[{'id':s['id'],'title':s['title'],'tests':[{'status':t['status'],'expectedStatus':t['expectedStatus'],'attempts':[{'status':a['status'],'retry':a['retry'],'duration':a.get('duration')} for a in t['results']]} for t in s['tests']]} for s in specs(report['suites'])]
 archive=ROOT/f'ui-shard-{n}-results.tar.gz'
 with tarfile.open(archive,'w:gz') as tf:
  if (UI/'test-results').exists():tf.add(UI/'test-results',arcname='test-results')
 r['results_archive_sha256']=sha(archive);state['results'].append(r);state.pop('active',None);save();print(json.dumps({'shard':n,'exit':code,'stats':r.get('stats')},ensure_ascii=False),flush=True)
 if code!=0:state['state']='needs_diagnosis';save();break
else:state.update(state='completed',end=now());save()
