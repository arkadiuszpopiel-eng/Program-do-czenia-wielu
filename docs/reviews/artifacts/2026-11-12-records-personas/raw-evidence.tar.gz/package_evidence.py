"""Copy only explicitly selected, synthetic test evidence after timed UI stops."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
target = Path('/workspace/wt-jarvis/docs/reviews/artifacts/2026-11-12-records-personas')
ui = json.loads((root / 'ui-shards-resume.json').read_text())
assert ui['state'] == 'completed', 'Do not write repo or compress during timed UI'
assert (root / 'ui-coverage-verification.json').is_file()
target.mkdir(parents=True, exist_ok=True)
staging = root / 'final-evidence-staging'
assert not staging.exists(), 'Staging already exists: inspect before replacing'
staging.mkdir()
files = set()
stems = [
    'store-execution-unit-v1', 'store-execution-unit-v2', 'store-clippy',
    'records-core-red', 'records-core-green-v1', 'records-core-green-v2',
    'records-core-restart-overwrite', 'records-core-restart-denial', 'records-core-final',
    'workspace-tests-records', 'workspace-clippy-records-v2', 'cargo-deny-records',
    'library-role-red', 'library-role-green', 'library-schema-generate', 'library-workspace-clippy',
    'records-wire-tests', 'records-wire-tests-v2', 'records-wire-capture',
    'records-wire-clippy', 'records-wire-deny', 'records-wire-lock',
    'persona-units-integrated', 'persona-integrated-focus', 'persona-long-v11',
    'persona-long-v12', 'persona-focus-v13', 'persona-jarvis-final', 'atlas-wide-ui',
    'persona-final-types', 'persona-final-lint', 'persona-final-build',
    'persona-final-format', 'persona-final-bundle', 'integrated-prettier',
    'integrated-rust-format', 'atlas-wide-types', 'atlas-wide-lint',
    'atlas-wide-build', 'atlas-wide-bundle', 'atlas-wide-format',
    'custom-persona-ui-red', 'persona-types-red', 'ui-full-suite',
    'deny-junior-diagnostic',
    'integrated-final-core',
]
for stem in stems:
    for suffix in ['.json', '.log', '-report.json', '-results.tar.gz']:
        p = root / (stem + suffix)
        if p.is_file():
            files.add(p)
patterns = [
    'rust-*.log', 'rust-batches.json', 'rust-batches-verification.json',
    'rust-ignored-tests.json', 'workspace-target-metadata.json',
    'stale-test-executable-cleanup.json',
    'ui-shard-*-list.json', 'ui-shard-*-report.json', 'ui-shard-*.log',
    'ui-shard-*-results.tar.gz', 'ui-shards.json',
    'ui-resume-shard-*-list.json', 'ui-resume-shard-*-report.json',
    'ui-resume-shard-*.log', 'ui-resume-shard-*-results.tar.gz',
    'ui-shards-resume.json', 'ui-resume-resource-samples.jsonl',
    'ui-coverage-verification.json', 'ui-dist-manifest.json',
    'ui-full-results-original.tar.gz', 'post-ui-failure-resources.json',
    'persona-integrated-focus-results.tar.gz', 'persona-long-v11-results.tar.gz',
    'persona-long-v12-results.tar.gz', 'persona-focus-v13-results.tar.gz',
    'persona-jarvis-final-results.tar.gz', 'atlas-wide-ui-results.tar.gz',
    'custom-persona-red-original.tar.gz', 'custom-persona-red-evidence.tar.gz',
    'custom-persona-ui-red-evidence.log', 'custom-persona-green-v2-report.json',
    'core-pilot-pair.json', 'core-codec-bodies-manifest.json',
    'run_logged.py', 'rust_target_batches.py', 'ui_shard_runner.py',
    'ui_shard_resume.py', 'verify_ui_coverage.py', 'probe_core_records.py',
    'run_core_pilot_pair.py', 'server-verified.json', 'main-model-entry.json',
    'package_evidence.py', 'source-equivalence.json', 'github-before-final.json',
]
for pattern in patterns:
    files.update(p for p in root.glob(pattern) if p.is_file())
for directory in ['core-captured-records', 'core-codec-bodies',
                  'pilot-records_user_data', 'pilot-records_ablation']:
    files.update(p for p in (root / directory).rglob('*') if p.is_file())
manifest = []
for source in sorted(files):
    relative = source.relative_to(root)
    dest = staging / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    manifest.append({'path': relative.as_posix(), 'bytes': source.stat().st_size,
                     'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
(target / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
archive = target / 'raw-evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for source in sorted(staging.rglob('*')):
        if source.is_file():
            tar.add(source, arcname=source.relative_to(staging).as_posix(), recursive=False)
metadata = {'files': len(manifest), 'raw_bytes': sum(x['bytes'] for x in manifest),
            'archive_bytes': archive.stat().st_size,
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'manifest_sha256': hashlib.sha256((target / 'manifest.json').read_bytes()).hexdigest(),
            'scope': 'Exact original bytes. Synthetic fixtures only; no model weights, binary dependencies, private user sessions or actual provider credentials.'}
(target / 'archive.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
for name in ['ui-coverage-verification.json', 'rust-batches-verification.json',
             'rust-ignored-tests.json', 'core-codec-bodies-manifest.json']:
    shutil.copyfile(root / name, target / name)
print(json.dumps(metadata, ensure_ascii=False))
