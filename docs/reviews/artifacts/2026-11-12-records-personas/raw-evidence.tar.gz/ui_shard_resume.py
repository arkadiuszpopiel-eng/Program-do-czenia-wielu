"""Cztery kolejne lokalne shardy; nie zmienia CI/progów, zachowuje wszystkie wyniki."""
import datetime, hashlib, json, os, pathlib, subprocess, tarfile, threading, time
ROOT=pathlib.Path('/workspace/scratch/repair-20261111'); REPO=pathlib.Path('/workspace/wt-jarvis'); UI=REPO/'apps/desktop/ui'; STATE=ROOT/'ui-shards-resume.json'
env=os.environ.copy();env.update(PATH='/workspace/tools/pnpm/node_modules/.bin:'+env['PATH'],PW_WORKERS='1',CI='1')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO,text=True).strip()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def specs(suites):
 for s in suites:
  yield from s.get('specs',[])
  yield from specs(s.get('suites',[]))
assert not STATE.exists(),'Do not start duplicate run'
assert json.load(open(ROOT/'records-wire-tests-v2.json'))['exit']==0
assert json.load(open(ROOT/'records-wire-clippy.json'))['exit']==0
parent=json.load(open(ROOT/'ui-shards.json'))
assert parent['source']==git('rev-parse','HEAD') and parent['state']=='needs_diagnosis'
assert parent['results'][0]['exit']==0
assert json.loads((ROOT/'rust-batches.json').read_text())['state']=='completed'
assert not git('status','--porcelain'), 'Freeze source before full UI'
state={'source':git('rev-parse','HEAD'),'start':now(),'scope':'headless Linux/Chromium/fakeIPC; no hardware acceptance','controller':{'pid':os.getpid(),'group':os.getpgid(os.getpid()),'birth':pathlib.Path(f'/proc/{os.getpid()}/stat').read_text().split()[21]},'results':[],'state':'listing'}
def save():
 p=STATE.with_suffix('.tmp');p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');p.replace(STATE)
state['parent_attempt']=str(ROOT/'ui-shards.json');state['preserved_shards']=[parent['results'][0]];state['original_failure_unresolved']=True;state['resume_reason']='Same source and budgets. Original shard2:104pass/1fail/135notrun; isolated junior-dark5/5. Repeat shard2 once, then execute previously unrun3/4; preserve failure.'
save();sets=[]

resource_stop=threading.Event()
def sample_resources():
 base=pathlib.Path('/sys/fs/cgroup');previous=time.monotonic()
 with (ROOT/'ui-resume-resource-samples.jsonl').open('w') as f:
  while not resource_stop.wait(1):
   current=time.monotonic();sample={'at':now(),'interval_ms':round((current-previous)*1000)};previous=current
   for name in ['cpu.stat','memory.current','memory.events']:
    path=base/name
    if path.exists():sample[name]=path.read_text().strip()
   f.write(json.dumps(sample)+'\n');f.flush()
resource_thread=threading.Thread(target=sample_resources,daemon=True);resource_thread.start()

for n in range(1,5):
 p=ROOT/f'ui-resume-shard-{n}-list.json';r=subprocess.run(['pnpm','exec','playwright','test','--list',f'--shard={n}/4','--reporter=json'],cwd=UI,env=env,capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 p.write_text(r.stdout); report=json.loads(r.stdout);ids={s['id'] for s in specs(report['suites'])};assert ids;sets.append(ids)
all_ids=set().union(*sets);assert sum(map(len,sets))==len(all_ids),'shards overlap'
state['unique_tests']=len(all_ids);state['counts']=[len(s) for s in sets];save()
for n,expected in enumerate(sets,1):
 if n==1:continue
 assert git('rev-parse','HEAD')==state['source'] and not git('status','--porcelain')
 if (ROOT/'ui-shards.stop').exists():state['state']='stopped';save();break
 reportpath=ROOT/f'ui-resume-shard-{n}-report.json';env['PLAYWRIGHT_JSON_OUTPUT_FILE']=str(reportpath)
 cmd=['pnpm','exec','playwright','test',f'--shard={n}/4','--workers=1','--max-failures=1','--reporter=line,json'];log=ROOT/f'ui-resume-shard-{n}.log';r={'shard':n,'command':cmd,'expected_tests':len(expected),'start':now()};state.update(state='running',active=r)
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=UI,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);r.update(pid=p.pid,group=p.pid,birth=pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21]);save()
  while True:
   try:code=p.wait(timeout=30);break
   except subprocess.TimeoutExpired:state['heartbeat_at']=now();save()
 r.update(exit=code,end=now(),log_sha256=sha(log))
 if reportpath.exists():
  report=json.loads(reportpath.read_text());r['stats']=report['stats'];r['errors']=report.get('errors',[]);r['report_sha256']=sha(reportpath)
  seen={s['id'] for s in specs(report['suites'])};assert seen==expected, 'report targets changed'
  r['results']=[{'id':s['id'],'title':s['title'],'tests':[{'status':t['status'],'expectedStatus':t['expectedStatus'],'attempts':[{'status':a['status'],'retry':a['retry'],'duration':a.get('duration')} for a in t['results']]} for t in s['tests']]} for s in specs(report['suites'])]
 archive=ROOT/f'ui-resume-shard-{n}-results.tar.gz'
 with tarfile.open(archive,'w:gz') as tf:
  if (UI/'test-results').exists():tf.add(UI/'test-results',arcname='test-results')
 r['results_archive_sha256']=sha(archive);state['results'].append(r);state.pop('active',None);save();print(json.dumps({'shard':n,'exit':code,'stats':r.get('stats')},ensure_ascii=False),flush=True)
 if code!=0:state['state']='needs_diagnosis';save();break
else:state.update(state='completed',end=now());save()

resource_stop.set();resource_thread.join(timeout=2)
