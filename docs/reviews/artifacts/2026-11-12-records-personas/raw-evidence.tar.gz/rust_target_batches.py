"""Pełne cele Cargo w partiach; usuwa wyłącznie ukończone własne binaria testowe."""
import datetime, hashlib, json, os, pathlib, re, subprocess, sys, signal
ROOT=pathlib.Path('/workspace/scratch/repair-20261111');REPO=pathlib.Path('/workspace/wt-ledger-core-test');TARGET=pathlib.Path('/workspace/target-repair');HEAD='c5021d7af05f690fe7d90e1e6012620bdaca12cd'
INV=json.loads((ROOT/'workspace-target-inventory.json').read_text());STATE=ROOT/'rust-batches.json'
env=os.environ.copy();env.update(PATH='/workspace/tools/cargo/bin:/workspace/tools/cmake/cmake/data/bin:'+env['PATH'],RUSTUP_HOME='/workspace/tools/rustup',CARGO_HOME='/workspace/tools/cargo',RUSTUP_TOOLCHAIN='1.94.1',CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO,text=True).strip()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():
 temp=STATE.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2));temp.replace(STATE)
if STATE.exists():state=json.loads(STATE.read_text());assert state['source']==HEAD
else:
 names=INV['integration_names'];core={t['name'] for t in INV['targets'] if t['package']=='app-core' and t['kind']==['test']};ordered=['execution_records_context']+sorted(core-{'execution_records_context'})+sorted(set(names)-core)
 phases=[{'id':'integration-smoke','kind':'test','names':ordered[:1]}]
 phases += [{'id':f'integration-{i//6+1:03}','kind':'test','names':ordered[i:i+6]} for i in range(1,len(ordered),6)]
 phases += [{'id':'libraries','kind':'lib','names':[]},{'id':'binaries','kind':'bin','names':[t['name'] for t in INV['targets'] if t['kind']==['bin'] and t['test']]},{'id':'examples-build','kind':'examples','names':[]},{'id':'doctests','kind':'doc','names':[]}]
 state={'source':HEAD,'start':now(),'state':'prepared','scope':'same workspace/allfeatures; targetselection batches; no thresholds/policies changed; synthetic/Linux not hardware','phases':phases,'completed':[],'results':[]}
assert git('rev-parse','HEAD')==HEAD and git('status','--porcelain')==''
state['controller']={'pid':os.getpid(),'group':os.getpgid(os.getpid()),'birth':pathlib.Path(f'/proc/{os.getpid()}/stat').read_text().split()[21],'script_sha256':sha(pathlib.Path(__file__))};save()
signal.signal(signal.SIGHUP, signal.SIG_IGN)
for phase in state['phases']:
 if phase['id'] in state['completed']:continue
 assert git('rev-parse','HEAD')==HEAD and git('status','--porcelain')==''
 if (ROOT/'rust-batches.stop').exists():state['state']='stopped';save();break
 if os.statvfs(TARGET).f_bavail*os.statvfs(TARGET).f_frsize<1500*1024**2:state['state']='needs_disk_space';save();raise SystemExit('Need1.5GiB before next phase')
 kind=phase['kind'];cmd=['cargo','+1.94.1','build' if kind=='examples' else 'test','--locked','--workspace','--all-features','-j2','--message-format=json']
 if kind=='examples':cmd+=['--examples']
 else:
  cmd+=['--no-fail-fast']
  if kind in ['lib','doc']:cmd+=['--'+kind]
  else:
   for name in phase['names']:cmd+=['--'+kind,name]
  cmd+=['--','--test-threads=1']
 log=ROOT/('rust-'+phase['id']+'.log');result={'id':phase['id'],'kind':kind,'names':phase['names'],'command':cmd,'start':now()};state['state']='running';state['active']=result
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);result.update(pid=p.pid,group=p.pid,birth=pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21]);save()
  while True:
   try:code=p.wait(timeout=30);break
   except subprocess.TimeoutExpired:
    state['heartbeat_at']=now();save();print(json.dumps({'active':phase['id'],'pid':p.pid,'heartbeat_at':state['heartbeat_at']}),flush=True)
 result.update(exit=code,end=now(),log_sha256=sha(log));artifacts={};counts=[]
 with log.open(errors='replace') as f:
  for line in f:
   if line.startswith('{'):
    try:item=json.loads(line)
    except json.JSONDecodeError:continue
    if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('profile',{}).get('test'):
     artifacts[item['executable']]={'package_id':item['package_id'],'target':item['target']['name'],'kind':item['target']['kind'],'fresh':item['fresh']}
   match=re.search(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
   if match:counts.append({'status':match[1],'passed':int(match[2]),'failed':int(match[3]),'ignored':int(match[4])})
 result['test_results']=counts;result['artifacts']=[];result['released_bytes']=0
 for raw,meta in artifacts.items():
  path=pathlib.Path(raw);assert path.parent.resolve()==(TARGET/'debug/deps').resolve(),raw
  if not path.exists():continue
  meta.update(path=str(path),bytes=path.stat().st_size,sha256=sha(path));result['artifacts'].append(meta)
  if code==0:path.unlink();result['released_bytes']+=meta['bytes']
 state['results'].append(result);state.pop('active',None)
 if code!=0:state['state']='needs_diagnosis';save();print(json.dumps({'phase':phase['id'],'exit':code,'log':str(log)}),flush=True);raise SystemExit(code)
 state['completed'].append(phase['id']);save();print(json.dumps({'phase':phase['id'],'exit':0,'summaries':len(counts),'passed':sum(c['passed'] for c in counts),'failed':sum(c['failed'] for c in counts),'ignored':sum(c['ignored'] for c in counts),'released_bytes':result['released_bytes']}),flush=True)
 if '--smoke' in sys.argv:state['state']='paused_after_smoke';save();break
else:state['state']='completed';state['end']=now();save()
