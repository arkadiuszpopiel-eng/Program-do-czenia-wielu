"""Dwa kolejne ekrany surowego HTTP; brak automatycznych ponowień lub zmian progów."""
import datetime,json,pathlib,subprocess,os,hashlib
R=pathlib.Path('/workspace/scratch/repair-20261111');P=R/'core-pilot-pair.json'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not P.exists()
for name in ['library-workspace-clippy','integrated-build','persona-units-integrated']:
 assert json.load(open(R/(name+'.json')))['exit']==0
s={'state':'running','start':now(),'controller':{'pid':os.getpid(),'group':os.getpgid(os.getpid()),'birth':pathlib.Path(f'/proc/{os.getpid()}/stat').read_text().split()[21]},'results':[]}
def save():
 q=P.with_suffix('.tmp');q.write_text(json.dumps(s,indent=2)+'\n');q.replace(P)
save()
for name in ['records_user_data','records_ablation']:
 with (R/(name+'-pilot-controller.log')).open('wb') as f:
  p=subprocess.Popen(['python',str(R/'probe_core_records.py'),name],stdout=f,stderr=subprocess.STDOUT,start_new_session=True);s['active']={'variant':name,'pid':p.pid,'group':p.pid,'birth':pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21]};save()
  while True:
   try:code=p.wait(timeout=30);break
   except subprocess.TimeoutExpired:s['heartbeat_at']=now();save()
 s['results'].append({'variant':name,'exit':code,'status':str(R/('pilot-'+name)/'status.json')});s.pop('active',None);save()
s.update(state='completed',end=now());save()
