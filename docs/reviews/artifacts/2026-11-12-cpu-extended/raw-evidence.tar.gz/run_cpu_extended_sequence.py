import datetime,hashlib,json,pathlib,subprocess,time
r=pathlib.Path(__file__).parent
wt='/workspace/wt-cpu-model-diagnosis'
def run(key,cmd):
 subprocess.run(['python3',str(r/'run_logged.py'),key,wt,*cmd],check=True)
 d=json.loads((r/(key+'.json')).read_text())
 print(json.dumps({'stage':key,'exit':d['exit']},ensure_ascii=False),flush=True)
 return d['exit']
while json.loads((r/'cpu-extended-build.json').read_text())['state']=='running':time.sleep(2)
assert json.loads((r/'cpu-extended-build.json').read_text())['exit']==0
pins=json.loads((r/'actual-read-pins.json').read_text())
for row in pins['files']:
 with pathlib.Path(row['path']).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']
print('Qwen8B and server hashes verified; no cold-cache timing claim',flush=True)
def attempt(model,key):
 return run(key,['timeout','--signal=TERM','--kill-after=5s','720s','env',
  'ALFA_CPU_DIAGNOSTIC_SECONDS=180',
  'ALFA_LIVE_SERVER=/workspace/tools/llama/llama-b11559/llama-server',
  'ALFA_LIVE_MODELS_DIR=/workspace/models','ALFA_LIVE_MODEL='+model,
  'ALFA_ACTUAL_READ_REPORT='+str(r/(key+'-report.json')),
  'cargo','+1.94.1','test','--locked','-p','app-core','--test','execution_actual_read',
  'capture_actual_read_on_local_model','-j','2','--','--ignored','--exact','--nocapture'])
attempt('qwen3-8b-q4-k-m','cpu-extended-8b')
print('8B finished; next public pinned11B download, no model running',flush=True)
if run('cpu-extended-11b-download',['python3',str(r/'cpu_diag_download.py')])==0:
 attempt('bielik-11b-v2.3-instruct-q4-k-m','cpu-extended-11b')
run('cpu-extended-default-control',['cargo','+1.94.1','test','--locked','-p','app-core','--test','execution_actual_read','-j','2'])
run('cpu-extended-clippy',['cargo','+1.94.1','clippy','--locked','-p','app-core','--test','execution_actual_read','-j','2','--','-D','warnings'])
print('Sequence finished; inspect raw reports, no automatic semantic acceptance',flush=True)
