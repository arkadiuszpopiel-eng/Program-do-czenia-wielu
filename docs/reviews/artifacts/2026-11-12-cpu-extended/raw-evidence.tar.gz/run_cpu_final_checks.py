import pathlib,json,subprocess,time
r=pathlib.Path(__file__).parent;wt='/workspace/wt-cpu-model-diagnosis'
f=r/'cpu-grounding-14b-empty.json'
while not f.exists() or json.loads(f.read_text())['state']!='completed':time.sleep(2)
commands=[
 ('cpu-final-format',['cargo','+1.94.1','fmt','--all','--','--check']),
 ('cpu-final-controls',['cargo','+1.94.1','test','--locked','-p','app-core','--test','execution_actual_read','--test','execution_records_live','--test','jarvis_live','-j','2']),
 ('cpu-final-clippy',['cargo','+1.94.1','clippy','--locked','-p','app-core','--all-targets','-j','2','--','-D','warnings'])]
for key,cmd in commands:
 subprocess.run(['python3',str(r/'run_logged.py'),key,wt,*cmd],check=True)
 print(json.dumps({'stage':key,'exit':json.loads((r/(key+'.json')).read_text())['exit']}),flush=True)
