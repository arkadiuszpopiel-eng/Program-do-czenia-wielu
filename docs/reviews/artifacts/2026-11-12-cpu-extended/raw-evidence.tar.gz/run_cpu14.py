import json,pathlib,subprocess
r=pathlib.Path(__file__).parent;wt='/workspace/wt-cpu-model-diagnosis'
assert json.loads((r/'cpu-extended-clippy.json').read_text())['state']=='completed'
assert json.loads((r/'cpu-diag-11b-download.json').read_text())['verification']=='MATCH'
assert json.loads((r/'cpu-extended-11b.json').read_text())['state']=='completed'
latest_report=r/'cpu-extended-11b-600-report.json' if (r/'cpu-extended-11b-600-report.json').exists() else r/'cpu-extended-11b-report.json'
if not json.loads(latest_report.read_text()).get('transport_ok'):
 print('11B has no answer; preserve cache for longer CPU diagnosis before14B',flush=True)
 raise SystemExit(0)
entry=json.loads((r/'cpu-diag-11b-entry.json').read_text());p=pathlib.Path('/workspace/models')/entry['file']
assert pathlib.Path(str(p)+'.sha256').read_text().strip()==entry['sha256']
assert p.stat().st_size==6724050496
p.unlink();pathlib.Path(str(p)+'.sha256').unlink()
(r/'cpu-11b-cache-retired.json').write_text(json.dumps({'file':str(p),'reason':'only newly downloaded reproducible11B cache removed after completed test to fit14B; raw reports and pinned manifest preserved','sha256':entry['sha256']},indent=2)+'\n')
def run(key,args):
 subprocess.run(['python3',str(r/'run_logged.py'),key,wt,*args],check=True)
 d=json.loads((r/(key+'.json')).read_text());print(json.dumps({'stage':key,'exit':d['exit']}),flush=True);return d['exit']
if run('cpu-extended-14b-download',['python3',str(r/'cpu_diag_download14.py')])==0:
 rc=run('cpu-extended-14b',['timeout','--signal=TERM','--kill-after=5s','1980s','env',
  'ALFA_CPU_DIAGNOSTIC_SECONDS=600','ALFA_CPU_DIAGNOSTIC_MAX_TOKENS=512',
  'ALFA_LIVE_SERVER=/workspace/tools/llama/llama-b11559/llama-server','ALFA_LIVE_MODELS_DIR=/workspace/models',
  'ALFA_LIVE_MODEL=qwen3-14b-q3-k-m-cpu-diagnostic','ALFA_LIVE_MODEL_ENTRY='+str(r/'cpu-diag-14b-entry.json'),
  'ALFA_ACTUAL_READ_REPORT='+str(r/'cpu-extended-14b-report.json'),
  'cargo','+1.94.1','test','--locked','-p','app-core','--test','execution_actual_read',
  'capture_actual_read_on_local_model','-j','2','--','--ignored','--exact','--nocapture'])

 if rc==0:
  run('cpu-extended-14b-empty',['timeout','--signal=TERM','--kill-after=5s','1980s','env',
   'ALFA_CPU_DIAGNOSTIC_SECONDS=600','ALFA_CPU_DIAGNOSTIC_MAX_TOKENS=512','ALFA_CPU_DIAGNOSTIC_EMPTY=1',
   'ALFA_LIVE_SERVER=/workspace/tools/llama/llama-b11559/llama-server','ALFA_LIVE_MODELS_DIR=/workspace/models',
   'ALFA_LIVE_MODEL=qwen3-14b-q3-k-m-cpu-diagnostic','ALFA_LIVE_MODEL_ENTRY='+str(r/'cpu-diag-14b-entry.json'),
   'ALFA_ACTUAL_READ_REPORT='+str(r/'cpu-extended-14b-empty-report.json'),
   'cargo','+1.94.1','test','--locked','-p','app-core','--test','execution_actual_read',
   'capture_actual_read_on_local_model','-j','2','--','--ignored','--exact','--nocapture'])
