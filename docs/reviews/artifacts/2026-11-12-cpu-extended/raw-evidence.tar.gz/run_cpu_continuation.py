import json,pathlib,subprocess,time
r=pathlib.Path(__file__).parent;wt='/workspace/wt-cpu-model-diagnosis'
def run(key,args):
 subprocess.run(['python3',str(r/'run_logged.py'),key,wt,*args],check=True)
 d=json.loads((r/(key+'.json')).read_text());print(json.dumps({'stage':key,'exit':d['exit']}),flush=True);return d['exit']
if run('cpu-extended-11b-resume',['python3',str(r/'resume_cpu11.py')])==0:
 while not (r/'cpu-extended-clippy.json').exists() or json.loads((r/'cpu-extended-clippy.json').read_text())['state']!='completed':time.sleep(2)
 run('cpu-extended-11b',['timeout','--signal=TERM','--kill-after=5s','720s','env','ALFA_CPU_DIAGNOSTIC_SECONDS=180',
  'ALFA_LIVE_SERVER=/workspace/tools/llama/llama-b11559/llama-server','ALFA_LIVE_MODELS_DIR=/workspace/models',
  'ALFA_LIVE_MODEL=bielik-11b-v2.3-instruct-q4-k-m','ALFA_ACTUAL_READ_REPORT='+str(r/'cpu-extended-11b-report.json'),
  'cargo','+1.94.1','test','--locked','-p','app-core','--test','execution_actual_read','capture_actual_read_on_local_model','-j','2','--','--ignored','--exact','--nocapture'])
 subprocess.run(['python3',str(r/'run_cpu14.py')],check=True)
