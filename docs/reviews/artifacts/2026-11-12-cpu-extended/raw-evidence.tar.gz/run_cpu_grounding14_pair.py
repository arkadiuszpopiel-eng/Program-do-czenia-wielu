import pathlib,json,subprocess,time
r=pathlib.Path(__file__).parent;wt='/workspace/wt-cpu-model-diagnosis'
while not (r/'cpu-system-8b-empty.json').exists() or json.loads((r/'cpu-system-8b-empty.json').read_text())['state']!='completed':time.sleep(2)
assert json.loads((r/'cpu-grounding-build-fixed.json').read_text())['exit']==0
for scenario in ['positive','empty']:
 key='cpu-grounding-14b-'+scenario
 cmd=['timeout','--signal=TERM','--kill-after=5s','1980s','env','ALFA_CPU_DIAGNOSTIC_SECONDS=600','ALFA_CPU_DIAGNOSTIC_GROUNDING_RULE=1','ALFA_CPU_DIAGNOSTIC_MAX_TOKENS=512',
 'ALFA_LIVE_SERVER=/workspace/tools/llama/llama-b11559/llama-server','ALFA_LIVE_MODELS_DIR=/workspace/models','ALFA_LIVE_MODEL=qwen3-14b-q3-k-m-cpu-diagnostic','ALFA_LIVE_MODEL_ENTRY='+str(r/'cpu-diag-14b-entry.json'),
 'ALFA_ACTUAL_READ_REPORT='+str(r/(key+'-report.json'))]
 if scenario=='empty':cmd+=['ALFA_CPU_DIAGNOSTIC_EMPTY=1']
 cmd+=['cargo','+1.94.1','test','--locked','-p','app-core','--test','execution_actual_read','capture_actual_read_on_local_model','-j','2','--','--ignored','--exact','--nocapture']
 subprocess.run(['python3',str(r/'run_logged.py'),key,wt,*cmd],check=True)
 print(json.dumps({'stage':key,'exit':json.loads((r/(key+'.json')).read_text())['exit']}),flush=True)
