import concurrent.futures,datetime,hashlib,json,os,pathlib,time,urllib.request
r=pathlib.Path(__file__).parent;e=json.loads((r/'cpu-diag-11b-entry.json').read_text());total=6724050496;p=pathlib.Path('/workspace/models')/(e['file']+'.cpu-diag-part');target=p.with_name(e['file']);assert p.exists() and not target.exists()
parts=[]
with p.open('rb') as f:
 for i in range(4):
  start=total*i//4;end=total*(i+1)//4
  hole=os.lseek(f.fileno(),start,os.SEEK_HOLE)
  resume=max(start,min(hole,end)-1048576)
  for j in range(4):
   a=resume+(end-resume)*j//4;b=resume+(end-resume)*(j+1)//4-1
   if a<=b:parts.append({'start':a,'end':b,'bytes':0})
s={'state':'resuming','entry':e,'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parts':parts,'method':'SEEK_HOLE per original contiguous range,1MiB overlap,8threads; full SHA mandatory','previous':'cpu-diag-11b-download-first.json','transfer_limit_s':1800}
def save(): (r/'cpu-diag-11b-resume.json').write_text(json.dumps(s,indent=2)+'\n')
save()
def get(part):
 begin=time.monotonic();a,b=part['start'],part['end'];req=urllib.request.Request(e['url'],headers={'Range':f'bytes={a}-{b}'})
 with urllib.request.urlopen(req,timeout=60) as response,p.open('r+b') as out:
  assert response.status==206 and response.headers['Content-Range']==f'bytes {a}-{b}/{total}'
  out.seek(a)
  while True:
   assert time.monotonic()-begin<1800
   data=response.read(256*1024)
   if not data:break
   out.write(data);part['bytes']+=len(data)
 assert part['bytes']==b-a+1
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(get,parts))
 with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 s['actual_sha256']=actual;assert actual==e['sha256']
 p.replace(target);pathlib.Path(str(target)+'.sha256').write_text(actual+'\n');s.update(state='completed',verification='MATCH');(r/'cpu-diag-11b-download.json').write_text(json.dumps(s,indent=2)+'\n')
except Exception as err:s.update(state='failed',error=type(err).__name__+': '+str(err)[:200]);raise
finally:s['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
