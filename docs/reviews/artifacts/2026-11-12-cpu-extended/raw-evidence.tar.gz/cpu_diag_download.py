import concurrent.futures, datetime, hashlib, json, os, pathlib, shutil, sys, time, urllib.request
root=pathlib.Path(__file__).parent
entry=json.loads((root/'cpu-diag-11b-entry.json').read_text())
total=6724050496
target=pathlib.Path('/workspace/models')/entry['file'];part=pathlib.Path(str(target)+'.cpu-diag-part')
assert not target.exists() and not part.exists()
assert shutil.disk_usage(target.parent).free > total+768*1024**2
status={'state':'downloading','start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entry':entry,'bytes_expected':total,'retries':0}
def save(): (root/'cpu-diag-11b-download.json').write_text(json.dumps(status,indent=2)+'\n')
save()
with part.open('wb') as f:f.truncate(total)
def get(i):
 start=total*i//4;end=total*(i+1)//4-1
 req=urllib.request.Request(entry['url'],headers={'Range':f'bytes={start}-{end}'})
 count=0;begin=time.monotonic()
 with urllib.request.urlopen(req,timeout=60) as response,part.open('r+b') as f:
  assert response.status==206 and response.headers['Content-Range']==f'bytes {start}-{end}/{total}'
  f.seek(start)
  while True:
   assert time.monotonic()-begin<900,'download900s'
   buf=response.read(256*1024)
   if not buf:break
   f.write(buf);count+=len(buf)
 assert count==end-start+1
 return count
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:status['ranges_bytes']=list(pool.map(get,range(4)))
 status['state']='verifying';save()
 with part.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 status['actual_sha256']=actual;assert actual==entry['sha256']
 part.replace(target);pathlib.Path(str(target)+'.sha256').write_text(actual+'\n')
 status['state']='completed';status['verification']='MATCH'
except Exception as e:
 status.update(state='failed',error=type(e).__name__+': '+str(e)[:200]);raise
finally:
 status['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
