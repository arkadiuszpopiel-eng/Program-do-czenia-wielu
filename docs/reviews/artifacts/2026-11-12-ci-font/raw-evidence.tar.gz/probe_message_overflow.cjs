const { chromium, expect } = require('/workspace/wt-jarvis/apps/desktop/ui/node_modules/@playwright/test');
const fs = require('node:fs');
const out = '/workspace/scratch/repair-20261111';
const id = 'w'.repeat(64);
(async () => {
  const browser = await chromium.launch();
  const results = [];
  async function run(worker) {
    for (let n = 0; n < 10; n++) {
      const context = await browser.newContext({ viewport: { width: 320, height: 844 }, locale: 'pl-PL', colorScheme: 'dark', reducedMotion: 'reduce' });
      const page = await context.newPage();
      await page.goto('http://127.0.0.1:4173/?scenario=custom-persona-long');
      await expect(page.locator('#alfa-composer')).toBeVisible({ timeout: 30000 });
      await expect(page.locator('#alfa-boot')).toHaveCount(0, { timeout: 30000 });
      const message = page.getByRole('article', { name: new RegExp(id) }).first();
      await expect(message).toBeVisible();
      const snapshots = [];
      for (let frame = 0; frame < 3; frame++) {
        snapshots.push(await message.evaluate((el) => {
          const root = el.getBoundingClientRect();
          return { scroll: el.scrollWidth, client: el.clientWidth, rect: root.toJSON(),
            overflow: [...el.querySelectorAll('*')].filter(x => x.getBoundingClientRect().right > root.right + 0.1).map(x => {
              const c = getComputedStyle(x); return { tag: x.tagName, class: x.className?.baseVal ?? x.className, rect: x.getBoundingClientRect().toJSON(), scroll: x.scrollWidth, client: x.clientWidth, min: c.minWidth, wrap: c.overflowWrap, white: c.whiteSpace, font: c.fontFamily, display: c.display };
            }) };
        }));
        await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      }
      const failed = snapshots.some(x => x.scroll > x.client);
      if (failed) await page.screenshot({ path: `${out}/overflow-${worker}-${n}.png` });
      results.push({ worker, n, failed, snapshots });
      fs.writeFileSync(`${out}/message-overflow-probe.json`, JSON.stringify({ scope: 'CI190 exact dist, same waitForChat, two contexts, 20 fresh navigations, geometry-only diagnosis', results }, null, 2));
      await context.close();
    }
  }
  await Promise.all([run(0), run(1)]);
  await browser.close();
  console.log(JSON.stringify({ total: results.length, overflow: results.filter(x => x.failed).length }));
})().catch(e => { console.error(e); process.exit(1); });
