const { chromium, expect } = require('/workspace/wt-jarvis/apps/desktop/ui/node_modules/@playwright/test');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch();
  const results = [];
  const context = await browser.newContext({ viewport: { width: 320, height: 844 }, locale: 'pl-PL', colorScheme: 'dark', reducedMotion: 'reduce' });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:4173/?scenario=custom-persona-long');
  await expect(page.locator('#alfa-composer')).toBeVisible();
  await expect(page.locator('#alfa-boot')).toHaveCount(0);
  const message = page.getByRole('article', { name: new RegExp('w'.repeat(64)) }).first();
  for (const font of ['system-ui', 'Arial', 'Liberation Sans', 'DejaVu Sans', 'Noto Sans', 'sans-serif', 'serif', 'monospace']) {
    await page.addStyleTag({ content: `:root { --alfa-font-sans: '${font}'; font-family: '${font}' }` });
    for (const width of [320, 321, 360, 390]) {
      await page.setViewportSize({ width, height: 844 });
      const geometry = await message.evaluate(el => {
        const b=el.getBoundingClientRect();
        return {scroll:el.scrollWidth,client:el.clientWidth,overflow:[...el.querySelectorAll('*')].filter(x=>x.getBoundingClientRect().right>b.right+0.1).map(x=>({tag:x.tagName,cls:x.className?.baseVal??x.className,width:x.getBoundingClientRect().width,right:x.getBoundingClientRect().right,wrap:getComputedStyle(x).overflowWrap,font:getComputedStyle(x).fontFamily}))};
      });
      results.push({font,width,...geometry});
    }
  }
  fs.writeFileSync('/workspace/scratch/repair-20261111/message-font-probe.json',JSON.stringify(results,null,2));
  console.log(JSON.stringify(results.filter(x=>x.scroll>x.client)));
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
